/**
 * Appliation entry point.
 */
public class Main
{
}
